#ifndef SHAPE_HPP
#define SHAPE_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class Shape
{
public:
    sf::Color m_color;
    sf::Vector2f m_position;
    sf::Sprite m_image;
    sf::FloatRect m_size;
};

#endif