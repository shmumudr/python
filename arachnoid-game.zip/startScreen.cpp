#include "../inc/startScreen.hpp"
#include <iostream>

void StartScreen::changeScreen()
{

    if (button1.isButtonClicked(m_window))
    {
        m_switch = true;
        m_status = GAME;
    }
    else if (button2.isButtonClicked(m_window))
    {
        m_window.close();
    }
}
void StartScreen::display()
{

    sf::Sprite image;
    image.setTexture(m_load.m_TSstart);

    sf::Vector2u windowSize = m_window.getSize();
    float scaleX = static_cast<float>(windowSize.x) / static_cast<float>(m_load.m_TSstart.getSize().x);
    float scaleY = static_cast<float>(windowSize.y) / static_cast<float>(m_load.m_TSstart.getSize().y);
    image.setPosition(sf::Vector2f(0, 0));
    image.setScale(scaleX, scaleY);

    changeScreen();

    m_window.clear();
    m_window.draw(image);
    button1.CursorOverButton(m_window);
    button2.CursorOverButton(m_window);

    button1.draw(m_window);
    button2.draw(m_window);
    m_window.display();
    m_input.handleInput(m_window);
}


