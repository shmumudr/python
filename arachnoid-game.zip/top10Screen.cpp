#include "../inc/top10Screen.hpp"
#include <iostream>

void Top10::createTop10Text()
{

    loadFromFile("top10.dat");

    for (int i = 0; i < int(players.size()); ++i)
    {
        m_top10_text[i].create(std::to_string(1 + i) + ": " + players[i].name + " : " + std::to_string(players[i].score) + " : " + std::to_string(players[i].time), 20, static_cast<float>(150.0f), float(i + 1) * 50.0f);
    }
}

void Top10::changeScreen()
{
}

void Top10::display()
{

    sf::Sprite image;
    image.setTexture(m_load.m_TSgame);

    sf::Vector2u windowSize = m_window.getSize();
    float scaleX = static_cast<float>(windowSize.x) / static_cast<float>(m_load.m_TSgame.getSize().x);
    float scaleY = static_cast<float>(windowSize.y) / static_cast<float>(m_load.m_TSgame.getSize().y);
    image.setPosition(sf::Vector2f(0, 0));
    image.setScale(scaleX, scaleY);

    switch (m_input.handleInput(m_window))
    {
    case TEXT:
        handleSetTExt();
        break;
    case ENTER:
        handleEnterText();
        break;

    default:
        break;
    }
    changeScreen();
    m_window.clear();
    m_window.draw(image);
    for (int i = 0; i < int(m_top10_text.size()); ++i)
    {
        m_top10_text[i].draw(m_window);
    }
    if (players.size() == 0 || m_player.score >= players[-1].score || players.size() < 10)
    {
        m_input.m_entered_text = true;
    }
    if (m_input.m_entered_text)
    {
        m_text.draw(m_window);
    }

    m_window.display();
}

void Top10::handleSetTExt()
{

    m_text.setText("PLEASE ENTER YOUR NAME : " + m_input.m_str);
}

void Top10::handleEnterText()
{
    m_player.name = m_input.m_str;
    players.emplace_back(m_player.name, m_player.score, m_player.time);
    saveToFile("top10.dat");
    createTop10Text();
}
