#include "../inc/text.hpp"
#include <iostream>

Text::Text()
{
    m_font.loadFromFile("/home/mefathim/m08.shmueldr/cpp/prj-01-arkanoid/images/arial.ttf");
};

void Text::create(std::string ButtonText, int TextSize, float x, float y)
{
    m_pos.x = x;
    m_pos.y = y;
    m_DefaultColor = sf::Color::Black;
    m_hColor = sf::Color::White;

    m_text.setFont(m_font);
    m_text.setCharacterSize(TextSize);
    m_text.setString(ButtonText);
    m_text.setOutlineColor(sf::Color::Black);
    m_text.setOutlineThickness(2);
    sf::FloatRect fr = m_text.getGlobalBounds();
    m_textBounds.x = fr.width + fr.left;
    m_textBounds.y = fr.height + fr.top;


    // m_text.setOrigin(m_textBounds.x / 2, m_textBounds.y / 2);
    m_text.setPosition(m_pos.x , m_pos.y  - 1);
}
void Text::draw(sf::RenderWindow &window) 
{
        window.draw(m_text);
}


void Text::setText(std::string ButtonText)
{
    m_text.setString(ButtonText);
}