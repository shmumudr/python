#ifndef COLLISION_HPP
#define COLLISION_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class Collision

{
public:
    bool ball_paddle(sf::Sprite &ball, sf::Sprite &paddle);
    bool ball_brick(sf::Sprite &ball, sf::Sprite &brick);
    bool ball_fall(sf::Sprite &ball, sf::Vector2u windowSize);
};
#endif