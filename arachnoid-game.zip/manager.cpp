#include "../inc/manager.hpp"

Manager::Manager()
{
    createScreen();
}

Manager::~Manager()
{
}

void Manager::switchToStartScreen()
{
    m_screen = std::make_unique<StartScreen>(window, m_load, s,status);
}

void Manager::switchToGameScreen()
{
    m_screen = std::make_unique<GameScreen>(window, m_load, s ,  m_player,status);
}

void Manager::switchToTop10Screen()
{
    m_screen = std::make_unique<Top10>(window, m_load, s, m_player,status);
}

void Manager::checkAndSwitchScreens()
{

    if (m_screen->m_switch)
    {

        switch (status)
        {
        case START:
            switchToStartScreen();
            break;

        case GAME:
            switchToGameScreen();
            break;

        case TOP_10:
            switchToTop10Screen();
            break;
        default:
            break;
        }
    }
}

void Manager::start_run()

{

    switchToStartScreen();
    while (m_screen->m_window.isOpen())
    {
        checkAndSwitchScreens();
        m_screen->display();
    }
}

void Manager::createScreen()
{
    window.create(sf::VideoMode(s.width_screen, s.hight_screen), "Arkanoid");
    window.setVerticalSyncEnabled(true);
    window.setKeyRepeatEnabled(true);

}
