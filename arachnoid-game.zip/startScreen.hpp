#ifndef STARTSCREEN_HPP
#define STARTSCREEN_HPP

#include "screen.hpp"
#include "input.hpp"
#include "button.hpp"

class StartScreen : public Screen
{
public:
    Button button1;
    Button button2;

    Input m_input;
    StartScreen(sf::RenderWindow &window, Load &load, Gms_settings &settings,Status& status)
        : Screen(window, load, settings,status)
    {

        button1.create("START", 20, 80.0, 40.0, 683, 250);
        button2.create("QUIT", 20, 80.0, 40.0, 683, 450);
    }
    void display() override;
    void changeScreen() override;
};

#endif