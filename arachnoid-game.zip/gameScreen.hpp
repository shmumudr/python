#ifndef GAMESCREEN_HPP
#define GAMESCREEN_HPP

#include "screen.hpp"
#include "input.hpp"
#include "paddle.hpp"
#include "ball.hpp"
#include "brick.hpp"
#include "collision.hpp"
#include "button.hpp"
#include "text.hpp"
#include "setting.hpp"
#include "timer.hpp"

class GameScreen : public Screen
{
public:
    Ball m_ball;
    Paddle m_paddle;
    Collision collision;
    Input m_input;
    Text m_text_score;
    Text m_text_life;
    Text m_text_time;
    int m_life;
    sf::Timer timer;
    Player &m_player;

    Text m_game_over;

    Gms_settings s;
    bool m_bar = false;
    int m_playerLife = s.m_playerLife;

    std::vector<std::unique_ptr<Bricks>> m_grid;

GameScreen(sf::RenderWindow &window, Load &load, Gms_settings &settings,  Player &player,Status& status)
    : Screen(window, load, settings,status), 
      m_ball(load.m_Tball, settings.paddle_pos), 
      m_paddle(load.m_Tpaddle, settings.paddle_pos),
      m_player(player)
{
    createGrid();
    timer.Pause();
    m_life = s.m_playerLife;
    m_text_score.create("SCORE : 0", 20, 50.0f, 40.0f);
    m_text_life.create("LIFE :" + std::to_string(m_life), 20, 200.0f, 40.0f);
    m_text_time.create("TIME : ", 20, 400.0f, 40.0f);
}
    void display() override;
    void changeScreen() override {}
    void createGrid();
    void handleBallPaddleCollision();
    void checkColiisionBallBrick();
    void handleCollisionBallBrick(int index);
    void checkBallFall();
    void updateScore();
    void handleScore();
    void updateLife();
    void handleLife();
    void resetBallAndPaddle();
    void gameOver();
    void getPlayerInfo();
    void win();
};

#endif