#ifndef BRICK_HPP
#define BRICK_HPP

#include "bricks.hpp"

class Brick : public Bricks
{
public:
    Brick(sf::Vector2f init_pos, sf::Texture &img, sf::Color c)
    {

        m_image.setTexture(img);
        m_image.setColor(c);
        m_position = init_pos;
        m_image.setPosition(m_position);
        m_size = m_image.getGlobalBounds();
    }
};

#endif
