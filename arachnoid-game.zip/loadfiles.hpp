#ifndef LOADFILE_HPP
#define LOADFILE_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class Load

{
public:
    sf::Texture m_Tpaddle;
    sf::Texture m_Tball;
    sf::Texture m_Tbrick;
    sf::Texture m_TSstart;
    sf::Texture m_TSgame;

    Load()
    {

        m_Tpaddle.loadFromFile("images/paddleBlu.png");
        m_Tball.loadFromFile("images/ball.png");
        m_Tbrick.loadFromFile("images/block1.png");
        m_TSstart.loadFromFile("images/arkanoid.png");
        m_TSgame.loadFromFile("images/level0.png");
    }
};

#endif