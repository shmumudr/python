#include "inc/manager.hpp"

int main()
{

    Manager manager;
    manager.start_run();

    return 0;
}