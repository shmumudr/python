
#ifndef SETTINGS_HPP
#define SETTINGS_HPP

#include <SFML/Graphics.hpp>

class Settings
{
public:
    int width_screen = 1280;
    int hight_screen = 800;

    std::string title = "Arkanoid";
};

class Gms_settings : public Settings
{
public:
    std::string bg_img = "images/wp4470724-1280x720-wallpapers.jpg";
    std::string paddle_img = "images/paddleBlu.png";
    std::string ball_img = "images/paddleBlu.png";
    sf::Vector2f paddle_pos = sf::Vector2f(float(width_screen / 2), float(hight_screen - 120));
    sf::Vector2f ball_pos = sf::Vector2f(30, 683);
    sf::Vector2f ball_speed = sf::Vector2f(2, 4);
    int regularBrick = 40;
    int m_playerLife = 3;
    
};
#endif