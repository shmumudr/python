#ifndef MANAGER_HPP
#define MANAGER_HPP

#include <memory>
#include <SFML/Graphics.hpp>
#include "startScreen.hpp"
#include "gameScreen.hpp"
#include "top10Screen.hpp"

#include "loadfiles.hpp"
#include "setting.hpp"
#include "status.hpp"
#include "player.hpp"


class Manager
{
public:
    sf::RenderWindow window;
    std::unique_ptr<Screen> m_screen;
    bool gameStarted = false;
    Load m_load;
    Gms_settings s;
    Status status;
    Player m_player{"shmu",0,0 };

    Manager();
    ~Manager();
    void createScreen();
    void start_run();
    void switchToStartScreen();
    void switchToGameScreen();
    void switchToTop10Screen();

    void checkAndSwitchScreens();
};

#endif
