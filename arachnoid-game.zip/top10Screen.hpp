#ifndef TOP10SCREEN_HPP
#define TOP10SCREEN_HPP

#include "screen.hpp"
#include "button.hpp"
#include "input.hpp"
#include "text.hpp"

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <SFML/System.hpp>

class Top10 : public Screen
{
private:
    Player &m_player;
    Input m_input;
    Text m_text;
    std::vector<Text> m_top10_text{10};
    std::string m_str;

    std::vector<Player> players;

public:
    void display() override;
    void getUserNAME();
    void handleSetTExt();
    void handleEnterText();

    void changeScreen() override;
    Top10(sf::RenderWindow &window, Load &load, Gms_settings &settings, Player &player, Status &status)
        : Screen(window, load, settings, status), m_player(player)
    {
        createTop10Text();
        m_input.set_enter_text(true);
        m_text.create("PLEASE ENTER YOUT NAME : ", 40, float(m_settings.width_screen / 2), float(m_settings.hight_screen / 2));

    }

    void addPlayer(const std::string &name, int score, const float time)
    {
        players.emplace_back(name, score, time);
        sortPlayers();
        truncateToTop10();
        saveToFile("top10.dat");
    }

private:
    void loadFromFile(const std::string &filename)
    {
        std::ifstream file(filename);
        if (!file.is_open())
        {
            std::cerr << "Error opening file: " << filename << std::endl;
            return;
        }

        players.clear();
        std::string name;
        int score;
        float timeMs;

        while (file >> name >> score >> timeMs)
        {
            players.emplace_back(name, score, timeMs);
        }

        file.close();
        sortPlayers();
        truncateToTop10();
    }

    void saveToFile(const std::string &filename) const
    {
        std::ofstream file(filename);
        if (!file.is_open())
        {
            std::cerr << "Error opening file for writing: " << filename << std::endl;
            return;
        }

        for (const auto &player : players)
        {
            file << player.name << " " << player.score << " " << player.time << std::endl;
        }

        file.close();
    }

    void sortPlayers()
    {
        if (players.size()>0)
        {std::sort(players.begin(), players.end(), [](const Player &a, const Player &b)
                  {
            if (a.score == b.score) {
                return a.time < b.time;
            }
            return a.score > b.score; });}
    }

    void truncateToTop10()
    {
        if (players.size() > 10)
        {
            players.resize(10);
        }
    }
    void createTop10Text();
};

#endif