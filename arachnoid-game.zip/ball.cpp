#include "../inc/ball.hpp"

void Ball::move(sf::Vector2u window)
{
    adjustSpeed(window, m_image, m_position);
    m_image.move(m_position);
};

void Ball::adjustSpeed(sf::Vector2u const &size, sf::Sprite &ball, sf::Vector2f &speed)
{
    sf::Vector2f pos = ball.getPosition();
    sf::Rect ball_size = m_image.getGlobalBounds();

    if (pos.x >= static_cast<float>(size.x) - ball_size.width)
        speed.x *= -1;
    if (pos.x <= 0)
        speed.x *= -1;
    // if (pos.y >= static_cast<float>(size.y))
    //     speed.y *= -1;
    if (pos.y <= 0)
        speed.y *= -1;
}