#include <SFML/System/Clock.hpp>

namespace sf
{
    struct Timer
    {
        sf::Clock mC;
        float runTime;
        bool bPaused;

        Timer()
        {
            bPaused = false;
            runTime = 0;
            mC.restart();
        }

        void Reset()
        {
            mC.restart();
            runTime = 0;
            bPaused = false;
        }

        void Start()
        {
            if (bPaused)
            {
                mC.restart();
            }
            bPaused = false;
        }

        void Pause()
        {
            if (!bPaused)
            {
                runTime += mC.getElapsedTime().asSeconds();
            }
            bPaused = true;
        }

        float GetElapsedSeconds()
        {
            if (!bPaused)
            {
                return runTime + mC.getElapsedTime().asSeconds();
            }
            return runTime;
        }
    };
}
