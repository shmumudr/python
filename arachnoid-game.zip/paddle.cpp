// paddle.cpp
#include "../inc/paddle.hpp"

void Paddle::move(sf::Vector2u windowSize, float deltaTime)
{
    m_velocity = m_smoothness * m_velocity + (1.0f - m_smoothness) * m_speed * m_direction;

    float movement = m_velocity * deltaTime;

    sf::Vector2f newPosition = m_position + sf::Vector2f(movement, 0);

    if (newPosition.x >= 0 && newPosition.x + m_size.width <= static_cast<float>(windowSize.x) - 180)
    {
        m_position = newPosition;
    }
}

