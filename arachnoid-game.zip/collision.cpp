#include "../inc/collision.hpp"
#include <iostream>

bool Collision::ball_paddle(sf::Sprite &ball, sf::Sprite &paddle)
{
    return ball.getGlobalBounds().intersects(paddle.getGlobalBounds());
}

bool Collision::ball_brick(sf::Sprite &ball, sf::Sprite &brick)
{
    return ball.getGlobalBounds().intersects(brick.getGlobalBounds());
}

bool Collision::ball_fall(sf::Sprite &ball, sf::Vector2u windowSize)
{
    return ball.getPosition().y > static_cast<float>(windowSize.y);
}
