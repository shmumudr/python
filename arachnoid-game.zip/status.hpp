#ifndef STATUS_HPP
#define STATUS_HPP



enum Status

{
    START,
    GAME,
    GAME_OVER,
    TOP_10
};

#endif