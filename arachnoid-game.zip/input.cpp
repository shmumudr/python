#include "../inc/input.hpp"

#include <iostream>

Input::Input() {}

input Input::handleInput(sf::RenderWindow &window)

{
    sf::Event event;
    while (window.pollEvent(event))
    {
        switch (event.type)
        {
        case sf::Event::Closed:
            window.close();
            break;

        case sf::Event::TextEntered:
            return handle_enter_text(event);
            break;

        case sf::Event::KeyPressed:
            switch (event.key.code)
            {
            case sf::Keyboard::Escape:
                window.close();
                break;

            case sf::Keyboard::Left:
                return LEFT;
                break;

            case sf::Keyboard::Right:
                return RIGHT;
                break;

            case sf::Keyboard::Space:
                return SPACE;
                break;
            case sf::Keyboard::Enter:
                set_enter_text(false);
                return ENTER;
                break;
            default:
                break;
            }
            break;
        default:;
        }
    }
    return MOUSE;
}

input Input::handle_enter_text(sf::Event &event)
{
    if (event.text.unicode < 128 && m_entered_text)
    {
        if (event.text.unicode != 8)
        {
            m_str += static_cast<char>(event.text.unicode);
        }
        else if (event.text.unicode == 8 && !m_str.empty())
        {
            m_str.pop_back();
        }
        return TEXT;
    }

    return MOUSE;
}

void Input::set_enter_text(bool boole)
{
    if (!m_str.empty())
    {
        m_entered_text = boole;
    }
}

// {
//     sf::Event event;
//     while (window.pollEvent(event))
//     {
//         switch (event.type)
//         {
//         case sf::Event::Closed:
//             window.close();
//             break;
//         case sf::Event::KeyPressed:
//             switch (event.key.code)
//             {
//             case sf::Keyboard::Escape:
//                 window.close();
//                 break;
//             case sf::Keyboard::Left:
//                 return LEFT;
//                 break;
//             case sf::Keyboard::Right:
//                 return RIGHT;
//                 break;
//             case sf::Keyboard::Space:
//                 return SPACE;
//                 break;

//             default:
//                 break;
//             }
//             break;
//         default:;
//         };
//     }
//     return CLOSE;
// }