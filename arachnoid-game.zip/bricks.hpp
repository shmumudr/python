#ifndef BRICKS_HPP
#define BRICKS_HPP

#include "shape.hpp"

class Bricks : public Shape
{
};

#endif
