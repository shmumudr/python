// paddle.hpp
#ifndef PADDLE_HPP
#define PADDLE_HPP

#include "shape.hpp"

class Paddle : public Shape
{
public:
    float m_speed = 2000.0f;
    float m_smoothness = 0.1f;
    float m_velocity = 10.0f;
    float m_direction = 0;

    Paddle(sf::Texture &texture, sf::Vector2f &pos)
    {
        m_image.setTexture(texture);
        m_image.setScale(1.5,1);
        m_position = pos;
        m_image.setPosition(m_position);
    };

    void move(sf::Vector2u windowSize, float deltaTime);
};

#endif
