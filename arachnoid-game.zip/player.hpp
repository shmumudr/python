#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include <SFML/System.hpp>


struct Player
{
    std::string name;
    int score;
    float time;
    Player(){};

    Player(const std::string &n, int s,  float t) : name(n), score(s), time(t) {}
};
#endif