#ifndef INPUT_HPP
#define INPUT_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
enum input
{
    CLOSE = 10,
    RIGHT,
    LEFT,
    SPACE,
    ENTER,
    TEXT,
    MOUSE
};

class Input
{

public:
    Input();
    std::string m_str;
    bool m_entered_text = false;

    input handleInput(sf::RenderWindow &window);
    void set_enter_text(bool boole);
    input handle_enter_text(sf::Event &event);
};

#endif