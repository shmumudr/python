#include "shape.hpp"

class Ball : public Shape
{
public:
    int m_direction;
    const float m_speed = 10.0f; 


    Ball(sf::Texture& texture,sf::Vector2f& pos)

    {
        m_image.setTexture(texture);
        m_image.setPosition(pos);
        m_position = sf::Vector2f(2, 4);
        m_size = m_image.getGlobalBounds();
    };
    void adjustSpeed(sf::Vector2u const &size, sf::Sprite &ball, sf::Vector2f &speed);
    void move(sf::Vector2u windowSize);
};