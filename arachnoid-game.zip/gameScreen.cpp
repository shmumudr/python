#include "../inc/gameScreen.hpp"
#include <iostream>
#include <memory>
#include "../inc/button.hpp"
#include <cmath>
#include <chrono>
#include <thread>
#include <iomanip>

sf::Clock gameClock;
sf::Clock timeClock;
sf::Timer timer;

float deltaTime = 0.0f;

void GameScreen::createGrid()
{
    sf::Vector2f topLeft(0.0f, 0.0f);
    float spacing = 2.0f;
    std::vector<sf::Color> colors = {
        sf::Color::Red,
        sf::Color::White,
        sf::Color::Blue};
    for (int i = 2; i < 5; ++i)
    {
        sf::Color c = colors[i - 2];
        for (int j = 5; j < 6; ++j)
        {
            float brickPosX = static_cast<float>(m_load.m_Tbrick.getSize().x * j) + spacing * static_cast<float>(j);
            float brickPosY = static_cast<float>(m_load.m_Tbrick.getSize().y * i) + spacing * static_cast<float>(i);

            sf::Vector2f brickPosition(brickPosX, brickPosY);

            m_grid.push_back(std::make_unique<Brick>(brickPosition, m_load.m_Tbrick, c));
        }
    }
}

void GameScreen::handleBallPaddleCollision()
{
    sf::Vector2f ballPos = m_ball.m_image.getPosition();
    sf::FloatRect paddleBounds = m_paddle.m_image.getGlobalBounds();

    float paddleCenterX = paddleBounds.left + paddleBounds.width / 2.f;
    float hitFactor = (ballPos.x - paddleCenterX) / (paddleBounds.width / 2.f);

    float angle = static_cast<float>(hitFactor * M_PI / 3);

    m_ball.m_position = sf::Vector2f(std::sin(angle) * m_ball.m_speed, std::cos(angle) * m_ball.m_speed);

    if (m_ball.m_position.y > 0)
    {
        m_ball.m_position.y *= -1;
    }
}

void GameScreen::checkColiisionBallBrick()
{
    for (int i = 0; i < static_cast<int>(m_grid.size()); ++i)
    {

        if (collision.ball_brick(m_ball.m_image, m_grid[i]->m_image))
        {
            handleCollisionBallBrick(i);
            break;
        }
    }
}

void GameScreen::handleCollisionBallBrick(int index)
{
    sf::Vector2f pos_ball = m_ball.m_image.getPosition();
    sf::FloatRect brickBounds = m_grid[index]->m_image.getGlobalBounds();

    float ballRadius = std::min(m_ball.m_image.getLocalBounds().width / 2.f, m_ball.m_image.getLocalBounds().height / 2.f);

    if (m_ball.m_image.getGlobalBounds().intersects(brickBounds))
    {
        if (pos_ball.x + ballRadius >= brickBounds.left && pos_ball.x - ballRadius <= brickBounds.left + brickBounds.width)
            m_ball.m_position.y *= -1;

        if (pos_ball.y + ballRadius >= brickBounds.top && pos_ball.y - ballRadius <= brickBounds.top + brickBounds.height)
            m_ball.m_position.x *= -1;

        m_grid.erase(std::next(m_grid.begin(), index));
        handleScore();
    }
}

void GameScreen::updateScore()
{
    m_player.score += s.regularBrick;
}
void GameScreen::handleScore()
{
    updateScore();
    m_text_score.setText("SCORE :" + std::to_string(m_player.score));
}
void GameScreen::updateLife()
{
    m_life -= 1;
}
void GameScreen::handleLife()
{
    updateLife();
    m_text_life.setText("LIFE :" + std::to_string(m_life));
}
void GameScreen::checkBallFall()
{
    if (collision.ball_fall(m_ball.m_image, m_window.getSize()))
    {
        m_bar = false;
        resetBallAndPaddle();
    }
}

void GameScreen::getPlayerInfo()
{
    m_player.time = timer.GetElapsedSeconds();
}

void GameScreen::resetBallAndPaddle()
{
    m_ball.m_image.setPosition(m_paddle.m_position);
    handleLife();
}
void GameScreen::gameOver()
{
    if (m_life <= 0)
    {

        m_game_over.create("GAME IS  OVER!", 50, static_cast<float>(s.width_screen / 2), static_cast<float>(s.hight_screen / 2));
        m_game_over.draw(m_window);
        m_text_life.draw(m_window);

        m_window.display();
        std::this_thread::sleep_for(std::chrono::seconds(static_cast<int>(2.0f)));

        m_switch = true;
        m_status = START;
    }
}

void GameScreen::win()
{
    if (m_grid.empty())
    {
        m_switch = true;
        m_status = TOP_10;
        getPlayerInfo();
    }
}

void GameScreen::display()
{
    sf::Time elapsed = gameClock.restart();
    deltaTime = elapsed.asSeconds();
    float seconds = timer.GetElapsedSeconds();

    std::stringstream ss;
    ss << "TIME : " << std::fixed << std::setprecision(1) << seconds << " seconds";
    std::string result = ss.str();

    sf::Sprite screen_image;
    screen_image.setTexture(m_load.m_TSgame);

    sf::Vector2u windowSize = m_window.getSize();
    float scaleX = static_cast<float>(windowSize.x) / static_cast<float>(m_load.m_TSgame.getSize().x);
    float scaleY = static_cast<float>(windowSize.y) / static_cast<float>(m_load.m_TSgame.getSize().y);
    screen_image.setPosition(sf::Vector2f(0, 0));
    screen_image.setScale(scaleX, scaleY);
    m_text_time.setText(result);

    switch (m_input.handleInput(m_window))
    {
    case 11:
        m_paddle.m_direction = 1;
        m_paddle.move(windowSize, deltaTime);
        break;
    case 12:
        m_paddle.m_direction = -1;
        m_paddle.move(windowSize, deltaTime);

        break;
    case 13:
        m_bar = true;
        timer.Start();
        break;

    default:
        break;
    }
    m_paddle.m_image.setPosition(m_paddle.m_position);
    if (m_bar)
    {
        m_ball.move(windowSize);
    }
    else
    {

        sf::Vector2f paddlePosition = m_paddle.m_image.getPosition();
        sf::FloatRect paddleBounds = m_paddle.m_image.getGlobalBounds();
        float ballX = paddlePosition.x + (paddleBounds.width / 2) - (m_ball.m_image.getGlobalBounds().width / 2);
        float ballY = paddlePosition.y - m_ball.m_image.getGlobalBounds().height;
        m_ball.m_image.setPosition(ballX, ballY);
    }
    m_window.clear();
    m_window.draw(screen_image);
    m_window.draw(m_paddle.m_image);
    m_window.draw(m_ball.m_image);
    for (const auto &brick : m_grid)
    {
        m_window.draw(brick->m_image);
    }
    m_text_score.draw(m_window);
    m_text_life.draw(m_window);
    m_text_time.draw(m_window);

    if (collision.ball_paddle(m_ball.m_image, m_paddle.m_image))
    {
        handleBallPaddleCollision();
    }
    checkColiisionBallBrick();
    checkBallFall();
    gameOver();
    win();

    m_window.display();
}