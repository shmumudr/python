#ifndef SCREEN_HPP
#define SCREEN_HPP
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "loadfiles.hpp"
#include "setting.hpp"
#include "status.hpp"
#include "player.hpp"


class Screen
{
public:
    virtual void display() = 0;
    sf::RenderWindow &m_window;
    Load &m_load;
    Gms_settings &m_settings;
    bool m_switch;
    Status&m_status;

    Screen(sf::RenderWindow &window, Load &load, Gms_settings &settings,Status& status)
        : m_window(window), m_load(load), m_settings(settings),  m_switch(false),m_status(status)
    {
    }
    virtual void changeScreen() = 0;
};
#endif