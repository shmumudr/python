#ifndef TEXT_HPP
#define TEXT_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class Text
{

public:
    Text();

    void create(std::string ButtonText, int TextSize, float x, float y);
    void draw(sf::RenderWindow &window);
    void setText(std::string ButtonText);

public:
    sf::Font m_font;
    sf::Text m_text;
    sf::Vector2f m_textPos;
    sf::Vector2f m_textBounds;

    sf::Vector2f m_pos;
    // sf::Vector2f m_size;

    sf::Color m_DefaultColor;
    sf::Color m_hColor;

};
#endif